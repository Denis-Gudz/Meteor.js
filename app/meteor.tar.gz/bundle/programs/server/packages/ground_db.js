(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var ECMAScript = Package.ecmascript.ECMAScript;
var MongoID = Package['mongo-id'].MongoID;
var ReactiveVar = Package['reactive-var'].ReactiveVar;
var DiffSequence = Package['diff-sequence'].DiffSequence;
var LocalCollection = Package.minimongo.LocalCollection;
var Minimongo = Package.minimongo.Minimongo;
var _ = Package.underscore._;
var EJSON = Package.ejson.EJSON;
var EventState = Package['raix:eventstate'].EventState;
var meteorInstall = Package.modules.meteorInstall;
var meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
var Promise = Package.promise.Promise;

/* Package-scope variables */
var Ground, ServerTime;

var require = meteorInstall({"node_modules":{"meteor":{"ground:db":{"lib":{"server":{"ground.db.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/ground_db/lib/server/ground.db.js                                       //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
let ServerTime;
module.link("./servertime", {
  default(v) {
    ServerTime = v;
  }

}, 0);
Ground = {};
Ground.Collection = class GroundCollection {
  constructor()
  /* name, options = {} */
  {
    throw new Error('Ground.Collection is client-side only');
  }

};
module.exportDefault({
  Ground
});
//////////////////////////////////////////////////////////////////////////////////////

},"servertime.js":function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////
//                                                                                  //
// packages/ground_db/lib/server/servertime.js                                      //
//                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////
                                                                                    //
////////////////////////// GET SERVER TIME DIFFERENCE //////////////////////////
ServerTime = {}; // XXX: TODO use a http rest point instead - creates less overhead

Meteor.methods({
  'getServerTime': function () {
    return Date.now();
  }
}); // Unify client / server api

ServerTime.now = function () {
  return Date.now();
};

module.exportDefault(ServerTime);
//////////////////////////////////////////////////////////////////////////////////////

}}}}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

var exports = require("/node_modules/meteor/ground:db/lib/server/ground.db.js");

/* Exports */
Package._define("ground:db", exports, {
  Ground: Ground
});

})();

//# sourceURL=meteor://💻app/packages/ground_db.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvZ3JvdW5kOmRiL2xpYi9zZXJ2ZXIvZ3JvdW5kLmRiLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9wYWNrYWdlcy9ncm91bmQ6ZGIvbGliL3NlcnZlci9zZXJ2ZXJ0aW1lLmpzIl0sIm5hbWVzIjpbIlNlcnZlclRpbWUiLCJtb2R1bGUiLCJsaW5rIiwiZGVmYXVsdCIsInYiLCJHcm91bmQiLCJDb2xsZWN0aW9uIiwiR3JvdW5kQ29sbGVjdGlvbiIsImNvbnN0cnVjdG9yIiwiRXJyb3IiLCJleHBvcnREZWZhdWx0IiwiTWV0ZW9yIiwibWV0aG9kcyIsIkRhdGUiLCJub3ciXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLFVBQUo7QUFBZUMsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSixjQUFVLEdBQUNJLENBQVg7QUFBYTs7QUFBekIsQ0FBM0IsRUFBc0QsQ0FBdEQ7QUFFZkMsTUFBTSxHQUFHLEVBQVQ7QUFFQUEsTUFBTSxDQUFDQyxVQUFQLEdBQW9CLE1BQU1DLGdCQUFOLENBQXVCO0FBQ3pDQyxhQUFXO0FBQUM7QUFBMEI7QUFDcEMsVUFBTSxJQUFJQyxLQUFKLENBQVUsdUNBQVYsQ0FBTjtBQUNEOztBQUh3QyxDQUEzQztBQUpBUixNQUFNLENBQUNTLGFBQVAsQ0FVZTtBQUFFTDtBQUFGLENBVmYsRTs7Ozs7Ozs7Ozs7QUNBQTtBQUVBTCxVQUFVLEdBQUcsRUFBYixDLENBRUE7O0FBQ0FXLE1BQU0sQ0FBQ0MsT0FBUCxDQUFlO0FBQ2IsbUJBQWlCLFlBQVc7QUFDMUIsV0FBT0MsSUFBSSxDQUFDQyxHQUFMLEVBQVA7QUFDRDtBQUhZLENBQWYsRSxDQU1BOztBQUNBZCxVQUFVLENBQUNjLEdBQVgsR0FBaUIsWUFBVztBQUMxQixTQUFPRCxJQUFJLENBQUNDLEdBQUwsRUFBUDtBQUNELENBRkQ7O0FBWkFiLE1BQU0sQ0FBQ1MsYUFBUCxDQWdCZVYsVUFoQmYsRSIsImZpbGUiOiIvcGFja2FnZXMvZ3JvdW5kX2RiLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFNlcnZlclRpbWUgZnJvbSAnLi9zZXJ2ZXJ0aW1lJztcblxuR3JvdW5kID0ge307XG5cbkdyb3VuZC5Db2xsZWN0aW9uID0gY2xhc3MgR3JvdW5kQ29sbGVjdGlvbiB7XG4gIGNvbnN0cnVjdG9yKC8qIG5hbWUsIG9wdGlvbnMgPSB7fSAqLykge1xuICAgIHRocm93IG5ldyBFcnJvcignR3JvdW5kLkNvbGxlY3Rpb24gaXMgY2xpZW50LXNpZGUgb25seScpO1xuICB9XG59O1xuXG5leHBvcnQgZGVmYXVsdCB7IEdyb3VuZCB9O1xuIiwiLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8gR0VUIFNFUlZFUiBUSU1FIERJRkZFUkVOQ0UgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cblxuU2VydmVyVGltZSA9IHt9O1xuXG4vLyBYWFg6IFRPRE8gdXNlIGEgaHR0cCByZXN0IHBvaW50IGluc3RlYWQgLSBjcmVhdGVzIGxlc3Mgb3ZlcmhlYWRcbk1ldGVvci5tZXRob2RzKHtcbiAgJ2dldFNlcnZlclRpbWUnOiBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gRGF0ZS5ub3coKTtcbiAgfVxufSk7XG5cbi8vIFVuaWZ5IGNsaWVudCAvIHNlcnZlciBhcGlcblNlcnZlclRpbWUubm93ID0gZnVuY3Rpb24oKSB7XG4gIHJldHVybiBEYXRlLm5vdygpO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgU2VydmVyVGltZTtcbiJdfQ==
