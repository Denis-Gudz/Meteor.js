(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var _ = Package.underscore._;
var ActiveRoute = Package['zimme:active-route'].ActiveRoute;

/* Package-scope variables */
var __coffeescriptShare, FlowRouterHelpers;

(function(){

///////////////////////////////////////////////////////////////////////////////////////
//                                                                                   //
// packages/arillo_flow-router-helpers/client/helpers.coffee.js                      //
//                                                                                   //
///////////////////////////////////////////////////////////////////////////////////////
                                                                                     //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var currentRouteName, currentRouteOption, func, helpers, isSubReady, name, param, pathFor, queryParam, subsReady, urlFor,                   
  slice = [].slice,
  hasProp = {}.hasOwnProperty;

subsReady = function() {
  var subs;
  subs = 1 <= arguments.length ? slice.call(arguments, 0) : [];
  if (subs.length === 1) {
    return FlowRouter.subsReady();
  }
  subs = subs.slice(0, subs.length - 1);
  return _.reduce(subs, function(memo, sub) {
    return memo && FlowRouter.subsReady(sub);
  }, true);
};

pathFor = function(path, view) {
  var hashBang, query, ref;
  if (view == null) {
    view = {
      hash: {}
    };
  }
  if (!path) {
    throw new Error('no path defined');
  }
  if (!view.hash) {
    view = {
      hash: view
    };
  }
  if (((ref = path.hash) != null ? ref.route : void 0) != null) {
    view = path;
    path = view.hash.route;
    delete view.hash.route;
  }
  query = view.hash.query ? FlowRouter._qs.parse(view.hash.query) : {};
  hashBang = view.hash.hash ? view.hash.hash : '';
  return FlowRouter.path(path, view.hash, query) + (hashBang ? "#" + hashBang : '');
};

urlFor = function(path, view) {
  var relativePath;
  relativePath = pathFor(path, view);
  return Meteor.absoluteUrl(relativePath.substr(1));
};

param = function(name) {
  return FlowRouter.getParam(name);
};

queryParam = function(key) {
  return FlowRouter.getQueryParam(key);
};

currentRouteName = function() {
  return FlowRouter.getRouteName();
};

currentRouteOption = function(optionName) {
  return FlowRouter.current().route.options[optionName];
};

isSubReady = function(sub) {
  if (sub) {
    return FlowRouter.subsReady(sub);
  }
  return FlowRouter.subsReady();
};

helpers = {
  subsReady: subsReady,
  pathFor: pathFor,
  urlFor: urlFor,
  param: param,
  queryParam: queryParam,
  currentRouteName: currentRouteName,
  isSubReady: isSubReady,
  currentRouteOption: currentRouteOption
};

if (Meteor.isClient) {
  for (name in helpers) {
    if (!hasProp.call(helpers, name)) continue;
    func = helpers[name];
    Template.registerHelper(name, func);
  }
}

if (Meteor.isServer) {
  FlowRouterHelpers = {
    pathFor: pathFor,
    urlFor: urlFor
  };
}

///////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
Package._define("arillo:flow-router-helpers", {
  FlowRouterHelpers: FlowRouterHelpers
});

})();

//# sourceURL=meteor://💻app/packages/arillo_flow-router-helpers.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvYXJpbGxvX2Zsb3ctcm91dGVyLWhlbHBlcnMvY2xpZW50L2hlbHBlcnMuY29mZmVlIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0E7RUFBQTs2QkFBQTs7QUFBQSxZQUFZO0FBQ1Y7QUFBQSxFQURXLDREQUNYO0FBQUEsTUFBaUMsSUFBSSxDQUFDLE1BQUwsS0FBZSxDQUFoRDtBQUFBLFdBQU8sVUFBVSxDQUFDLFNBQVgsRUFBUDtHQUFBO0FBQUEsRUFDQSxPQUFPLElBQUksQ0FBQyxLQUFMLENBQVcsQ0FBWCxFQUFjLElBQUksQ0FBQyxNQUFMLEdBQWMsQ0FBNUIsQ0FEUDtTQUVBLENBQUMsQ0FBQyxNQUFGLENBQVMsSUFBVCxFQUFlLFNBQUMsSUFBRCxFQUFPLEdBQVA7V0FDYixRQUFTLFVBQVUsQ0FBQyxTQUFYLENBQXFCLEdBQXJCLEVBREk7RUFBQSxDQUFmLEVBRUUsSUFGRixFQUhVO0FBQUEsQ0FBWjs7QUFBQSxPQVFBLEdBQVUsU0FBQyxJQUFELEVBQU8sSUFBUDtBQUNSOztJQURlLE9BQU87QUFBQSxNQUFDLE1BQUssRUFBTjs7R0FDdEI7QUFBQTtBQUFBLFVBQVUsVUFBTSxpQkFBTixDQUFWO0dBQUE7QUFFQSxXQUE2QixDQUFDLElBQTlCO0FBQUEsV0FBTztBQUFBLFlBQU0sSUFBTjtLQUFQO0dBRkE7QUFHQSxNQUFHLHdEQUFIO0FBQ0UsV0FBTyxJQUFQO0FBQUEsSUFDQSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsS0FEakI7QUFBQSxJQUVBLFdBQVcsQ0FBQyxJQUFJLENBQUMsS0FGakIsQ0FERjtHQUhBO0FBQUEsRUFPQSxRQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBYixHQUF3QixVQUFVLENBQUMsR0FBRyxDQUFDLEtBQWYsQ0FBcUIsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUEvQixDQUF4QixHQUFtRSxFQVAzRTtBQUFBLEVBUUEsV0FBYyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQWIsR0FBdUIsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFqQyxHQUEyQyxFQVJ0RDtTQVNBLFVBQVUsQ0FBQyxJQUFYLENBQWdCLElBQWhCLEVBQXNCLElBQUksQ0FBQyxJQUEzQixFQUFpQyxLQUFqQyxJQUEwQyxDQUFJLFFBQUgsR0FBaUIsTUFBSSxRQUFyQixHQUFxQyxFQUF0QyxFQVZsQztBQUFBLENBUlY7O0FBQUEsTUFxQkEsR0FBUyxTQUFDLElBQUQsRUFBTyxJQUFQO0FBQ1A7QUFBQSxpQkFBZSxRQUFRLElBQVIsRUFBYyxJQUFkLENBQWY7U0FDQSxNQUFNLENBQUMsV0FBUCxDQUFtQixZQUFZLENBQUMsTUFBYixDQUFvQixDQUFwQixDQUFuQixFQUZPO0FBQUEsQ0FyQlQ7O0FBQUEsS0EwQkEsR0FBUSxTQUFDLElBQUQ7U0FDTixVQUFVLENBQUMsUUFBWCxDQUFvQixJQUFwQixFQURNO0FBQUEsQ0ExQlI7O0FBQUEsVUE4QkEsR0FBYSxTQUFDLEdBQUQ7U0FDWCxVQUFVLENBQUMsYUFBWCxDQUF5QixHQUF6QixFQURXO0FBQUEsQ0E5QmI7O0FBQUEsZ0JBa0NBLEdBQW1CO1NBQ2pCLFVBQVUsQ0FBQyxZQUFYLEdBRGlCO0FBQUEsQ0FsQ25COztBQUFBLGtCQXNDQSxHQUFxQixTQUFDLFVBQUQ7U0FDbkIsVUFBVSxDQUFDLE9BQVgsRUFBb0IsQ0FBQyxLQUFLLENBQUMsT0FBUSxhQURoQjtBQUFBLENBdENyQjs7QUFBQSxVQTBDQSxHQUFhLFNBQUMsR0FBRDtBQUNYLE1BQW9DLEdBQXBDO0FBQUEsV0FBTyxVQUFVLENBQUMsU0FBWCxDQUFxQixHQUFyQixDQUFQO0dBQUE7QUFDQSxTQUFPLFVBQVUsQ0FBQyxTQUFYLEVBQVAsQ0FGVztBQUFBLENBMUNiOztBQUFBLE9BOENBLEdBQ0U7QUFBQSxhQUFXLFNBQVg7QUFBQSxFQUNBLFNBQVMsT0FEVDtBQUFBLEVBRUEsUUFBUSxNQUZSO0FBQUEsRUFHQSxPQUFPLEtBSFA7QUFBQSxFQUlBLFlBQVksVUFKWjtBQUFBLEVBS0Esa0JBQWtCLGdCQUxsQjtBQUFBLEVBTUEsWUFBWSxVQU5aO0FBQUEsRUFPQSxvQkFBb0Isa0JBUHBCO0NBL0NGOztBQXdEQSxJQUFHLE1BQU0sQ0FBQyxRQUFWO0FBQ0U7O3lCQUFBO0FBQUEsWUFBUSxDQUFDLGNBQVQsQ0FBd0IsSUFBeEIsRUFBOEIsSUFBOUI7QUFBQSxHQURGO0NBeERBOztBQTJEQSxJQUFHLE1BQU0sQ0FBQyxRQUFWO0FBQ0Usc0JBQ0U7QUFBQSxhQUFTLE9BQVQ7QUFBQSxJQUNBLFFBQVEsTUFEUjtHQURGLENBREY7Q0EzREEiLCJmaWxlIjoiL3BhY2thZ2VzL2FyaWxsb19mbG93LXJvdXRlci1oZWxwZXJzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIyBjaGVjayBmb3Igc3Vic2NyaXB0aW9ucyB0byBiZSByZWFkeVxuc3Vic1JlYWR5ID0gKHN1YnMuLi4pIC0+XG4gIHJldHVybiBGbG93Um91dGVyLnN1YnNSZWFkeSgpIGlmIHN1YnMubGVuZ3RoIGlzIDFcbiAgc3VicyA9IHN1YnMuc2xpY2UoMCwgc3Vicy5sZW5ndGggLSAxKVxuICBfLnJlZHVjZSBzdWJzLCAobWVtbywgc3ViKSAtPlxuICAgIG1lbW8gYW5kIEZsb3dSb3V0ZXIuc3Vic1JlYWR5KHN1YilcbiAgLCB0cnVlXG5cbiMgcmV0dXJuIHBhdGhcbnBhdGhGb3IgPSAocGF0aCwgdmlldyA9IHtoYXNoOnt9fSkgLT5cbiAgdGhyb3cgbmV3IEVycm9yKCdubyBwYXRoIGRlZmluZWQnKSB1bmxlc3MgcGF0aFxuICAjIHNldCBpZiBydW4gb24gc2VydmVyXG4gIHZpZXcgPSBoYXNoOiB2aWV3IHVubGVzcyB2aWV3Lmhhc2hcbiAgaWYgcGF0aC5oYXNoPy5yb3V0ZT9cbiAgICB2aWV3ID0gcGF0aFxuICAgIHBhdGggPSB2aWV3Lmhhc2gucm91dGVcbiAgICBkZWxldGUgdmlldy5oYXNoLnJvdXRlXG4gIHF1ZXJ5ID0gaWYgdmlldy5oYXNoLnF1ZXJ5IHRoZW4gRmxvd1JvdXRlci5fcXMucGFyc2Uodmlldy5oYXNoLnF1ZXJ5KSBlbHNlIHt9XG4gIGhhc2hCYW5nID0gaWYgdmlldy5oYXNoLmhhc2ggdGhlbiB2aWV3Lmhhc2guaGFzaCBlbHNlICcnXG4gIEZsb3dSb3V0ZXIucGF0aChwYXRoLCB2aWV3Lmhhc2gsIHF1ZXJ5KSArIChpZiBoYXNoQmFuZyB0aGVuIFwiIyN7aGFzaEJhbmd9XCIgZWxzZSAnJylcblxuIyByZXR1cm4gYWJzb2x1dGUgdXJsXG51cmxGb3IgPSAocGF0aCwgdmlldykgLT5cbiAgcmVsYXRpdmVQYXRoID0gcGF0aEZvcihwYXRoLCB2aWV3KVxuICBNZXRlb3IuYWJzb2x1dGVVcmwocmVsYXRpdmVQYXRoLnN1YnN0cigxKSlcblxuIyBnZXQgcGFyYW1ldGVyXG5wYXJhbSA9IChuYW1lKSAtPlxuICBGbG93Um91dGVyLmdldFBhcmFtKG5hbWUpO1xuXG4jIGdldCBxdWVyeSBwYXJhbWV0ZXJcbnF1ZXJ5UGFyYW0gPSAoa2V5KSAtPlxuICBGbG93Um91dGVyLmdldFF1ZXJ5UGFyYW0oa2V5KTtcblxuIyBnZXQgY3VycmVudCByb3V0ZSBuYW1lXG5jdXJyZW50Um91dGVOYW1lID0gKCkgLT5cbiAgRmxvd1JvdXRlci5nZXRSb3V0ZU5hbWUoKVxuXG4jIGdldCBjdXJyZW50IHJvdXRlIG9wdGlvbnNcbmN1cnJlbnRSb3V0ZU9wdGlvbiA9IChvcHRpb25OYW1lKSAtPlxuICBGbG93Um91dGVyLmN1cnJlbnQoKS5yb3V0ZS5vcHRpb25zW29wdGlvbk5hbWVdXG5cbiMgZGVwcmVjYXRlZFxuaXNTdWJSZWFkeSA9IChzdWIpIC0+XG4gIHJldHVybiBGbG93Um91dGVyLnN1YnNSZWFkeShzdWIpIGlmIHN1YlxuICByZXR1cm4gRmxvd1JvdXRlci5zdWJzUmVhZHkoKVxuXG5oZWxwZXJzID1cbiAgc3Vic1JlYWR5OiBzdWJzUmVhZHlcbiAgcGF0aEZvcjogcGF0aEZvclxuICB1cmxGb3I6IHVybEZvclxuICBwYXJhbTogcGFyYW1cbiAgcXVlcnlQYXJhbTogcXVlcnlQYXJhbVxuICBjdXJyZW50Um91dGVOYW1lOiBjdXJyZW50Um91dGVOYW1lXG4gIGlzU3ViUmVhZHk6IGlzU3ViUmVhZHlcbiAgY3VycmVudFJvdXRlT3B0aW9uOiBjdXJyZW50Um91dGVPcHRpb25cblxuaWYgTWV0ZW9yLmlzQ2xpZW50XG4gIFRlbXBsYXRlLnJlZ2lzdGVySGVscGVyIG5hbWUsIGZ1bmMgZm9yIG93biBuYW1lLCBmdW5jIG9mIGhlbHBlcnNcbiAgXG5pZiBNZXRlb3IuaXNTZXJ2ZXJcbiAgRmxvd1JvdXRlckhlbHBlcnMgPSBcbiAgICBwYXRoRm9yOiBwYXRoRm9yXG4gICAgdXJsRm9yOiB1cmxGb3JcbiJdfQ==
